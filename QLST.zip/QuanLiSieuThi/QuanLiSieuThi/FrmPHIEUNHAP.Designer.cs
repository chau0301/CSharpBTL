﻿
namespace QuanLiSieuThi
{
    partial class FrmPHIEUNHAP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.date = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.cboTENNCC = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cboNHANVIEN = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSLUONG = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDGIA = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGrid_PHIEUNHAP = new System.Windows.Forms.DataGridView();
            this.txtMAPN = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnXOA = new System.Windows.Forms.Button();
            this.btnTHEM = new System.Windows.Forms.Button();
            this.btnXUATHD = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGrid_CHITIET = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.txtTENHH = new System.Windows.Forms.TextBox();
            this.txtMAHH = new System.Windows.Forms.TextBox();
            this.txtDONGIA = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cboTENNGANH = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cboTENNHOM = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtTONG = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.txtSLUONG)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_PHIEUNHAP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_CHITIET)).BeginInit();
            this.SuspendLayout();
            // 
            // date
            // 
            this.date.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.date.Location = new System.Drawing.Point(47, 58);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(376, 29);
            this.date.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(32, 211);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 24);
            this.label1.TabIndex = 27;
            this.label1.Text = "Mã sản phẩm";
            // 
            // cboTENNCC
            // 
            this.cboTENNCC.DropDownHeight = 200;
            this.cboTENNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cboTENNCC.FormattingEnabled = true;
            this.cboTENNCC.IntegralHeight = false;
            this.cboTENNCC.Location = new System.Drawing.Point(529, 323);
            this.cboTENNCC.Name = "cboTENNCC";
            this.cboTENNCC.Size = new System.Drawing.Size(425, 32);
            this.cboTENNCC.TabIndex = 107;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label9.Location = new System.Drawing.Point(510, 296);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(134, 24);
            this.label9.TabIndex = 59;
            this.label9.Text = "Nhà cung cấp:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label10.Location = new System.Drawing.Point(702, 380);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(126, 24);
            this.label10.TabIndex = 61;
            this.label10.Text = "Tổng phải trả:";
            // 
            // cboNHANVIEN
            // 
            this.cboNHANVIEN.DropDownHeight = 200;
            this.cboNHANVIEN.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cboNHANVIEN.FormattingEnabled = true;
            this.cboNHANVIEN.IntegralHeight = false;
            this.cboNHANVIEN.Location = new System.Drawing.Point(47, 407);
            this.cboNHANVIEN.Name = "cboNHANVIEN";
            this.cboNHANVIEN.Size = new System.Drawing.Size(438, 32);
            this.cboNHANVIEN.TabIndex = 108;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(28, 380);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(197, 24);
            this.label2.TabIndex = 63;
            this.label2.Text = "Nhân viên nhận hàng:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(232, 210);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 24);
            this.label3.TabIndex = 65;
            this.label3.Text = "Tên sản phẩm:";
            // 
            // txtSLUONG
            // 
            this.txtSLUONG.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtSLUONG.Location = new System.Drawing.Point(529, 238);
            this.txtSLUONG.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.txtSLUONG.Name = "txtSLUONG";
            this.txtSLUONG.Size = new System.Drawing.Size(115, 29);
            this.txtSLUONG.TabIndex = 102;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(510, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 24);
            this.label4.TabIndex = 67;
            this.label4.Text = "Số lượng:";
            // 
            // txtDGIA
            // 
            this.txtDGIA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtDGIA.Location = new System.Drawing.Point(672, 238);
            this.txtDGIA.Name = "txtDGIA";
            this.txtDGIA.Size = new System.Drawing.Size(123, 29);
            this.txtDGIA.TabIndex = 103;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.Location = new System.Drawing.Point(652, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 24);
            this.label5.TabIndex = 69;
            this.label5.Text = "Đơn giá nhập:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataGrid_PHIEUNHAP);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 525);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1200, 175);
            this.panel1.TabIndex = 71;
            // 
            // dataGrid_PHIEUNHAP
            // 
            this.dataGrid_PHIEUNHAP.BackgroundColor = System.Drawing.Color.White;
            this.dataGrid_PHIEUNHAP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid_PHIEUNHAP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGrid_PHIEUNHAP.Location = new System.Drawing.Point(0, 0);
            this.dataGrid_PHIEUNHAP.Name = "dataGrid_PHIEUNHAP";
            this.dataGrid_PHIEUNHAP.Size = new System.Drawing.Size(1200, 175);
            this.dataGrid_PHIEUNHAP.TabIndex = 0;
            // 
            // txtMAPN
            // 
            this.txtMAPN.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtMAPN.Location = new System.Drawing.Point(47, 148);
            this.txtMAPN.Name = "txtMAPN";
            this.txtMAPN.ReadOnly = true;
            this.txtMAPN.Size = new System.Drawing.Size(376, 29);
            this.txtMAPN.TabIndex = 73;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.Location = new System.Drawing.Point(32, 114);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 24);
            this.label6.TabIndex = 72;
            this.label6.Text = "Mã phiếu nhập:";
            // 
            // btnXOA
            // 
            this.btnXOA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.btnXOA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnXOA.Location = new System.Drawing.Point(615, 394);
            this.btnXOA.Name = "btnXOA";
            this.btnXOA.Size = new System.Drawing.Size(58, 45);
            this.btnXOA.TabIndex = 110;
            this.btnXOA.Text = "-";
            this.btnXOA.UseVisualStyleBackColor = false;
            this.btnXOA.Click += new System.EventHandler(this.btnXOA_Click);
            // 
            // btnTHEM
            // 
            this.btnTHEM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.btnTHEM.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnTHEM.Location = new System.Drawing.Point(529, 394);
            this.btnTHEM.Name = "btnTHEM";
            this.btnTHEM.Size = new System.Drawing.Size(58, 45);
            this.btnTHEM.TabIndex = 109;
            this.btnTHEM.Text = "+";
            this.btnTHEM.UseVisualStyleBackColor = false;
            this.btnTHEM.Click += new System.EventHandler(this.btnTHEM_Click);
            // 
            // btnXUATHD
            // 
            this.btnXUATHD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.btnXUATHD.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnXUATHD.Location = new System.Drawing.Point(262, 462);
            this.btnXUATHD.Name = "btnXUATHD";
            this.btnXUATHD.Size = new System.Drawing.Size(175, 44);
            this.btnXUATHD.TabIndex = 112;
            this.btnXUATHD.Text = "Xuất hóa đơn";
            this.btnXUATHD.UseVisualStyleBackColor = false;
            this.btnXUATHD.Click += new System.EventHandler(this.btnXUATHD_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button1.Location = new System.Drawing.Point(47, 462);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(175, 44);
            this.button1.TabIndex = 111;
            this.button1.Text = "Phiếu nhập mới";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGrid_CHITIET
            // 
            this.dataGrid_CHITIET.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGrid_CHITIET.BackgroundColor = System.Drawing.Color.White;
            this.dataGrid_CHITIET.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid_CHITIET.Location = new System.Drawing.Point(529, -1);
            this.dataGrid_CHITIET.Name = "dataGrid_CHITIET";
            this.dataGrid_CHITIET.Size = new System.Drawing.Size(671, 188);
            this.dataGrid_CHITIET.TabIndex = 78;
            this.dataGrid_CHITIET.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGrid_CHITIET_CellContentClick);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label7.Location = new System.Drawing.Point(32, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(155, 24);
            this.label7.TabIndex = 79;
            this.label7.Text = "Ngày nhập hàng:";
            // 
            // txtTENHH
            // 
            this.txtTENHH.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtTENHH.Location = new System.Drawing.Point(248, 237);
            this.txtTENHH.Name = "txtTENHH";
            this.txtTENHH.Size = new System.Drawing.Size(237, 29);
            this.txtTENHH.TabIndex = 101;
            this.txtTENHH.TextChanged += new System.EventHandler(this.txtTENHH_TextChanged);
            // 
            // txtMAHH
            // 
            this.txtMAHH.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtMAHH.Location = new System.Drawing.Point(47, 238);
            this.txtMAHH.Name = "txtMAHH";
            this.txtMAHH.Size = new System.Drawing.Size(170, 29);
            this.txtMAHH.TabIndex = 100;
            // 
            // txtDONGIA
            // 
            this.txtDONGIA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtDONGIA.Location = new System.Drawing.Point(831, 238);
            this.txtDONGIA.Name = "txtDONGIA";
            this.txtDONGIA.Size = new System.Drawing.Size(123, 29);
            this.txtDONGIA.TabIndex = 104;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.Location = new System.Drawing.Point(812, 211);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 24);
            this.label8.TabIndex = 80;
            this.label8.Text = "Đơn giá bán:";
            // 
            // cboTENNGANH
            // 
            this.cboTENNGANH.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cboTENNGANH.FormattingEnabled = true;
            this.cboTENNGANH.ItemHeight = 24;
            this.cboTENNGANH.Location = new System.Drawing.Point(47, 323);
            this.cboTENNGANH.Name = "cboTENNGANH";
            this.cboTENNGANH.Size = new System.Drawing.Size(175, 32);
            this.cboTENNGANH.TabIndex = 105;
            this.cboTENNGANH.SelectedIndexChanged += new System.EventHandler(this.cboTENNGANH_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label12.Location = new System.Drawing.Point(28, 296);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(156, 24);
            this.label12.TabIndex = 83;
            this.label12.Text = "Tên ngành hàng:";
            // 
            // cboTENNHOM
            // 
            this.cboTENNHOM.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cboTENNHOM.FormattingEnabled = true;
            this.cboTENNHOM.ItemHeight = 24;
            this.cboTENNHOM.Location = new System.Drawing.Point(251, 323);
            this.cboTENNHOM.Name = "cboTENNHOM";
            this.cboTENNHOM.Size = new System.Drawing.Size(234, 32);
            this.cboTENNHOM.TabIndex = 106;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label13.Location = new System.Drawing.Point(232, 296);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(146, 24);
            this.label13.TabIndex = 85;
            this.label13.Text = "Tên nhóm hàng";
            // 
            // txtTONG
            // 
            this.txtTONG.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtTONG.Location = new System.Drawing.Point(728, 407);
            this.txtTONG.Name = "txtTONG";
            this.txtTONG.ReadOnly = true;
            this.txtTONG.Size = new System.Drawing.Size(226, 29);
            this.txtTONG.TabIndex = 87;
            // 
            // FrmPHIEUNHAP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 700);
            this.Controls.Add(this.txtTONG);
            this.Controls.Add(this.cboTENNHOM);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.cboTENNGANH);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtDONGIA);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dataGrid_CHITIET);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnXUATHD);
            this.Controls.Add(this.btnXOA);
            this.Controls.Add(this.btnTHEM);
            this.Controls.Add(this.txtMAPN);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtDGIA);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtSLUONG);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtTENHH);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cboNHANVIEN);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cboTENNCC);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtMAHH);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.date);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmPHIEUNHAP";
            this.Text = "FrmPHIEUNHAP";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmPHIEUNHAP_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtSLUONG)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_PHIEUNHAP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_CHITIET)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker date;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboTENNCC;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cboNHANVIEN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown txtSLUONG;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDGIA;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGrid_PHIEUNHAP;
        private System.Windows.Forms.TextBox txtMAPN;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnXOA;
        private System.Windows.Forms.Button btnTHEM;
        private System.Windows.Forms.Button btnXUATHD;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGrid_CHITIET;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtTENHH;
        private System.Windows.Forms.TextBox txtMAHH;
        private System.Windows.Forms.TextBox txtDONGIA;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cboTENNGANH;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cboTENNHOM;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtTONG;
    }
}