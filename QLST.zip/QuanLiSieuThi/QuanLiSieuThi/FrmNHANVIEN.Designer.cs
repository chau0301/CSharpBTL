﻿
namespace QuanLiSieuThi
{
    partial class FrmNHANVIEN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmNHANVIEN));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDIACHI = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTENNV = new System.Windows.Forms.TextBox();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.cboCHUCVU = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGrid_NHANVIEN = new System.Windows.Forms.DataGridView();
            this.btnTHEM = new System.Windows.Forms.Button();
            this.btnSUA = new System.Windows.Forms.Button();
            this.btnXOA = new System.Windows.Forms.Button();
            this.btnTIMKIEM_MANV = new System.Windows.Forms.Button();
            this.btnTIMKIEM_TENNV = new System.Windows.Forms.Button();
            this.cboGIOITINH = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtMANV = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_NHANVIEN)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(16, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã nhân viên:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(16, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên nhân viên:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(424, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Giới tính:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(424, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 24);
            this.label4.TabIndex = 5;
            this.label4.Text = "Địa chỉ:";
            // 
            // txtDIACHI
            // 
            this.txtDIACHI.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtDIACHI.Location = new System.Drawing.Point(442, 40);
            this.txtDIACHI.Name = "txtDIACHI";
            this.txtDIACHI.Size = new System.Drawing.Size(272, 29);
            this.txtDIACHI.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.Location = new System.Drawing.Point(424, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 24);
            this.label5.TabIndex = 8;
            this.label5.Text = "Số điện thoại:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.Location = new System.Drawing.Point(16, 165);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 24);
            this.label6.TabIndex = 9;
            this.label6.Text = "Chức vụ:";
            // 
            // txtTENNV
            // 
            this.txtTENNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtTENNV.Location = new System.Drawing.Point(35, 117);
            this.txtTENNV.Name = "txtTENNV";
            this.txtTENNV.Size = new System.Drawing.Size(272, 29);
            this.txtTENNV.TabIndex = 4;
            // 
            // txtSDT
            // 
            this.txtSDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtSDT.Location = new System.Drawing.Point(442, 117);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(272, 29);
            this.txtSDT.TabIndex = 7;
            this.txtSDT.TextChanged += new System.EventHandler(this.txtSDT_TextChanged);
            // 
            // cboCHUCVU
            // 
            this.cboCHUCVU.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cboCHUCVU.FormattingEnabled = true;
            this.cboCHUCVU.Location = new System.Drawing.Point(35, 192);
            this.cboCHUCVU.Name = "cboCHUCVU";
            this.cboCHUCVU.Size = new System.Drawing.Size(272, 32);
            this.cboCHUCVU.TabIndex = 5;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataGrid_NHANVIEN);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 300);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1300, 400);
            this.panel1.TabIndex = 16;
            // 
            // dataGrid_NHANVIEN
            // 
            this.dataGrid_NHANVIEN.BackgroundColor = System.Drawing.Color.White;
            this.dataGrid_NHANVIEN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGrid_NHANVIEN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid_NHANVIEN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGrid_NHANVIEN.Location = new System.Drawing.Point(0, 0);
            this.dataGrid_NHANVIEN.Name = "dataGrid_NHANVIEN";
            this.dataGrid_NHANVIEN.Size = new System.Drawing.Size(1300, 400);
            this.dataGrid_NHANVIEN.TabIndex = 0;
            this.dataGrid_NHANVIEN.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGrid_NHANVIEN_CellContentClick);
            // 
            // btnTHEM
            // 
            this.btnTHEM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.btnTHEM.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnTHEM.Location = new System.Drawing.Point(867, 34);
            this.btnTHEM.Name = "btnTHEM";
            this.btnTHEM.Size = new System.Drawing.Size(94, 35);
            this.btnTHEM.TabIndex = 17;
            this.btnTHEM.Text = "Thêm";
            this.btnTHEM.UseVisualStyleBackColor = false;
            this.btnTHEM.Click += new System.EventHandler(this.btnTHEM_Click);
            // 
            // btnSUA
            // 
            this.btnSUA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.btnSUA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnSUA.Location = new System.Drawing.Point(867, 111);
            this.btnSUA.Name = "btnSUA";
            this.btnSUA.Size = new System.Drawing.Size(94, 35);
            this.btnSUA.TabIndex = 18;
            this.btnSUA.Text = "Sửa";
            this.btnSUA.UseVisualStyleBackColor = false;
            this.btnSUA.Click += new System.EventHandler(this.btnSUA_Click);
            // 
            // btnXOA
            // 
            this.btnXOA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.btnXOA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnXOA.Location = new System.Drawing.Point(867, 189);
            this.btnXOA.Name = "btnXOA";
            this.btnXOA.Size = new System.Drawing.Size(94, 35);
            this.btnXOA.TabIndex = 19;
            this.btnXOA.Text = "Xóa";
            this.btnXOA.UseVisualStyleBackColor = false;
            this.btnXOA.Click += new System.EventHandler(this.btnXOA_Click);
            // 
            // btnTIMKIEM_MANV
            // 
            this.btnTIMKIEM_MANV.BackColor = System.Drawing.Color.Transparent;
            this.btnTIMKIEM_MANV.Image = ((System.Drawing.Image)(resources.GetObject("btnTIMKIEM_MANV.Image")));
            this.btnTIMKIEM_MANV.Location = new System.Drawing.Point(321, 32);
            this.btnTIMKIEM_MANV.Name = "btnTIMKIEM_MANV";
            this.btnTIMKIEM_MANV.Size = new System.Drawing.Size(37, 37);
            this.btnTIMKIEM_MANV.TabIndex = 22;
            this.btnTIMKIEM_MANV.UseVisualStyleBackColor = false;
            this.btnTIMKIEM_MANV.Click += new System.EventHandler(this.btnTIMKIEM_MANV_Click);
            // 
            // btnTIMKIEM_TENNV
            // 
            this.btnTIMKIEM_TENNV.BackColor = System.Drawing.Color.Transparent;
            this.btnTIMKIEM_TENNV.Image = ((System.Drawing.Image)(resources.GetObject("btnTIMKIEM_TENNV.Image")));
            this.btnTIMKIEM_TENNV.Location = new System.Drawing.Point(321, 109);
            this.btnTIMKIEM_TENNV.Name = "btnTIMKIEM_TENNV";
            this.btnTIMKIEM_TENNV.Size = new System.Drawing.Size(37, 37);
            this.btnTIMKIEM_TENNV.TabIndex = 23;
            this.btnTIMKIEM_TENNV.UseVisualStyleBackColor = false;
            this.btnTIMKIEM_TENNV.Click += new System.EventHandler(this.btnTIMKIEM_TENNV_Click);
            // 
            // cboGIOITINH
            // 
            this.cboGIOITINH.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cboGIOITINH.FormattingEnabled = true;
            this.cboGIOITINH.Location = new System.Drawing.Point(442, 192);
            this.cboGIOITINH.Name = "cboGIOITINH";
            this.cboGIOITINH.Size = new System.Drawing.Size(272, 32);
            this.cboGIOITINH.TabIndex = 8;
            this.cboGIOITINH.SelectedIndexChanged += new System.EventHandler(this.cboGIOITINH_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtMANV);
            this.panel2.Controls.Add(this.cboGIOITINH);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.btnTIMKIEM_TENNV);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.btnTIMKIEM_MANV);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.btnXOA);
            this.panel2.Controls.Add(this.btnSUA);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.btnTHEM);
            this.panel2.Controls.Add(this.txtDIACHI);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.cboCHUCVU);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.txtSDT);
            this.panel2.Controls.Add(this.txtTENNV);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1300, 300);
            this.panel2.TabIndex = 25;
            // 
            // txtMANV
            // 
            this.txtMANV.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtMANV.FormattingEnabled = true;
            this.txtMANV.Location = new System.Drawing.Point(35, 40);
            this.txtMANV.Name = "txtMANV";
            this.txtMANV.Size = new System.Drawing.Size(272, 32);
            this.txtMANV.TabIndex = 3;
            // 
            // FrmNHANVIEN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 700);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmNHANVIEN";
            this.Text = "NHANVIEN";
            this.Load += new System.EventHandler(this.FrmNHANVIEN_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_NHANVIEN)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDIACHI;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTENNV;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.ComboBox cboCHUCVU;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGrid_NHANVIEN;
        private System.Windows.Forms.Button btnTHEM;
        private System.Windows.Forms.Button btnSUA;
        private System.Windows.Forms.Button btnXOA;
        private System.Windows.Forms.Button btnTIMKIEM_MANV;
        private System.Windows.Forms.Button btnTIMKIEM_TENNV;
        private System.Windows.Forms.ComboBox cboGIOITINH;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox txtMANV;
    }
}