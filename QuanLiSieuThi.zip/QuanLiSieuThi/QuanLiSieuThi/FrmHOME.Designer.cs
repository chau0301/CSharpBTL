﻿
namespace QuanLiSieuThi
{
    partial class FrmHOME
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmHOME));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.picDOANHTHU = new System.Windows.Forms.PictureBox();
            this.btnDOANHTHU = new System.Windows.Forms.Button();
            this.picTK = new System.Windows.Forms.PictureBox();
            this.picINFO = new System.Windows.Forms.PictureBox();
            this.btnINFO = new System.Windows.Forms.Button();
            this.picNHANVIEN = new System.Windows.Forms.PictureBox();
            this.picCHUCVU = new System.Windows.Forms.PictureBox();
            this.picNCC = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.picHH = new System.Windows.Forms.PictureBox();
            this.picHD = new System.Windows.Forms.PictureBox();
            this.btnQLTK = new System.Windows.Forms.Button();
            this.btnHANGHOA = new System.Windows.Forms.Button();
            this.btnQLNCC = new System.Windows.Forms.Button();
            this.btnQLCV = new System.Windows.Forms.Button();
            this.btnHOADON = new System.Windows.Forms.Button();
            this.btnQLNV = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.mainpanel = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picDOANHTHU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picINFO)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNHANVIEN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCHUCVU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNCC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHD)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1028, 30);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(423, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(431, 29);
            this.label2.TabIndex = 6;
            this.label2.Text = "Phần mềm quản lý bán hàng siêu thị";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(51, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Quản lý siêu thị";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(45, 30);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.IndianRed;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(0, 0);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(31, 31);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "X";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.picDOANHTHU);
            this.panel2.Controls.Add(this.btnDOANHTHU);
            this.panel2.Controls.Add(this.picTK);
            this.panel2.Controls.Add(this.picINFO);
            this.panel2.Controls.Add(this.btnINFO);
            this.panel2.Controls.Add(this.picNHANVIEN);
            this.panel2.Controls.Add(this.picCHUCVU);
            this.panel2.Controls.Add(this.picNCC);
            this.panel2.Controls.Add(this.picHH);
            this.panel2.Controls.Add(this.picHD);
            this.panel2.Controls.Add(this.btnQLTK);
            this.panel2.Controls.Add(this.btnHANGHOA);
            this.panel2.Controls.Add(this.btnQLNCC);
            this.panel2.Controls.Add(this.btnQLCV);
            this.panel2.Controls.Add(this.btnHOADON);
            this.panel2.Controls.Add(this.btnQLNV);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel2.Location = new System.Drawing.Point(0, 30);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(201, 530);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // picDOANHTHU
            // 
            this.picDOANHTHU.BackColor = System.Drawing.Color.Transparent;
            this.picDOANHTHU.Location = new System.Drawing.Point(183, 292);
            this.picDOANHTHU.Margin = new System.Windows.Forms.Padding(0);
            this.picDOANHTHU.Name = "picDOANHTHU";
            this.picDOANHTHU.Size = new System.Drawing.Size(18, 50);
            this.picDOANHTHU.TabIndex = 17;
            this.picDOANHTHU.TabStop = false;
            // 
            // btnDOANHTHU
            // 
            this.btnDOANHTHU.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.btnDOANHTHU.FlatAppearance.BorderSize = 0;
            this.btnDOANHTHU.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDOANHTHU.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnDOANHTHU.ForeColor = System.Drawing.Color.Black;
            this.btnDOANHTHU.Image = ((System.Drawing.Image)(resources.GetObject("btnDOANHTHU.Image")));
            this.btnDOANHTHU.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDOANHTHU.Location = new System.Drawing.Point(0, 292);
            this.btnDOANHTHU.Name = "btnDOANHTHU";
            this.btnDOANHTHU.Size = new System.Drawing.Size(201, 50);
            this.btnDOANHTHU.TabIndex = 16;
            this.btnDOANHTHU.Text = "Phiếu nhập";
            this.btnDOANHTHU.UseVisualStyleBackColor = false;
            this.btnDOANHTHU.Click += new System.EventHandler(this.btnDOANHTHU_Click);
            // 
            // picTK
            // 
            this.picTK.BackColor = System.Drawing.Color.Transparent;
            this.picTK.Location = new System.Drawing.Point(183, 347);
            this.picTK.Margin = new System.Windows.Forms.Padding(0);
            this.picTK.Name = "picTK";
            this.picTK.Size = new System.Drawing.Size(18, 50);
            this.picTK.TabIndex = 14;
            this.picTK.TabStop = false;
            // 
            // picINFO
            // 
            this.picINFO.BackColor = System.Drawing.Color.Transparent;
            this.picINFO.Location = new System.Drawing.Point(183, 403);
            this.picINFO.Margin = new System.Windows.Forms.Padding(0);
            this.picINFO.Name = "picINFO";
            this.picINFO.Size = new System.Drawing.Size(18, 50);
            this.picINFO.TabIndex = 15;
            this.picINFO.TabStop = false;
            // 
            // btnINFO
            // 
            this.btnINFO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.btnINFO.FlatAppearance.BorderSize = 0;
            this.btnINFO.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnINFO.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnINFO.ForeColor = System.Drawing.Color.Black;
            this.btnINFO.Image = ((System.Drawing.Image)(resources.GetObject("btnINFO.Image")));
            this.btnINFO.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnINFO.Location = new System.Drawing.Point(0, 403);
            this.btnINFO.Name = "btnINFO";
            this.btnINFO.Size = new System.Drawing.Size(201, 50);
            this.btnINFO.TabIndex = 8;
            this.btnINFO.Text = "Thông tin";
            this.btnINFO.UseVisualStyleBackColor = false;
            this.btnINFO.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // picNHANVIEN
            // 
            this.picNHANVIEN.BackColor = System.Drawing.Color.Transparent;
            this.picNHANVIEN.Location = new System.Drawing.Point(183, 11);
            this.picNHANVIEN.Margin = new System.Windows.Forms.Padding(0);
            this.picNHANVIEN.Name = "picNHANVIEN";
            this.picNHANVIEN.Size = new System.Drawing.Size(18, 50);
            this.picNHANVIEN.TabIndex = 10;
            this.picNHANVIEN.TabStop = false;
            this.picNHANVIEN.Click += new System.EventHandler(this.picNHANVIEN_Click);
            // 
            // picCHUCVU
            // 
            this.picCHUCVU.BackColor = System.Drawing.Color.Transparent;
            this.picCHUCVU.Location = new System.Drawing.Point(183, 67);
            this.picCHUCVU.Margin = new System.Windows.Forms.Padding(0);
            this.picCHUCVU.Name = "picCHUCVU";
            this.picCHUCVU.Size = new System.Drawing.Size(18, 50);
            this.picCHUCVU.TabIndex = 11;
            this.picCHUCVU.TabStop = false;
            this.picCHUCVU.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // picNCC
            // 
            this.picNCC.BackColor = System.Drawing.Color.Transparent;
            this.picNCC.Location = new System.Drawing.Point(183, 125);
            this.picNCC.Margin = new System.Windows.Forms.Padding(0);
            this.picNCC.Name = "picNCC";
            this.picNCC.Size = new System.Drawing.Size(18, 50);
            this.picNCC.TabIndex = 12;
            this.picNCC.TabStop = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(228)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(0, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(200, 50);
            this.button2.TabIndex = 9;
            this.button2.Text = "Thoát";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // picHH
            // 
            this.picHH.BackColor = System.Drawing.Color.Transparent;
            this.picHH.Location = new System.Drawing.Point(183, 183);
            this.picHH.Margin = new System.Windows.Forms.Padding(0);
            this.picHH.Name = "picHH";
            this.picHH.Size = new System.Drawing.Size(18, 50);
            this.picHH.TabIndex = 13;
            this.picHH.TabStop = false;
            // 
            // picHD
            // 
            this.picHD.BackColor = System.Drawing.Color.Transparent;
            this.picHD.Location = new System.Drawing.Point(183, 239);
            this.picHD.Margin = new System.Windows.Forms.Padding(0);
            this.picHD.Name = "picHD";
            this.picHD.Size = new System.Drawing.Size(18, 50);
            this.picHD.TabIndex = 14;
            this.picHD.TabStop = false;
            // 
            // btnQLTK
            // 
            this.btnQLTK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.btnQLTK.FlatAppearance.BorderSize = 0;
            this.btnQLTK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLTK.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnQLTK.ForeColor = System.Drawing.Color.Black;
            this.btnQLTK.Image = ((System.Drawing.Image)(resources.GetObject("btnQLTK.Image")));
            this.btnQLTK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQLTK.Location = new System.Drawing.Point(0, 347);
            this.btnQLTK.Name = "btnQLTK";
            this.btnQLTK.Size = new System.Drawing.Size(201, 50);
            this.btnQLTK.TabIndex = 5;
            this.btnQLTK.Text = "Tài khoản";
            this.btnQLTK.UseVisualStyleBackColor = false;
            this.btnQLTK.Click += new System.EventHandler(this.btnQLTK_Click);
            // 
            // btnHANGHOA
            // 
            this.btnHANGHOA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.btnHANGHOA.FlatAppearance.BorderSize = 0;
            this.btnHANGHOA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHANGHOA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnHANGHOA.ForeColor = System.Drawing.Color.Black;
            this.btnHANGHOA.Image = ((System.Drawing.Image)(resources.GetObject("btnHANGHOA.Image")));
            this.btnHANGHOA.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHANGHOA.Location = new System.Drawing.Point(0, 183);
            this.btnHANGHOA.Name = "btnHANGHOA";
            this.btnHANGHOA.Size = new System.Drawing.Size(201, 50);
            this.btnHANGHOA.TabIndex = 7;
            this.btnHANGHOA.Text = "Hàng hóa";
            this.btnHANGHOA.UseVisualStyleBackColor = false;
            this.btnHANGHOA.Click += new System.EventHandler(this.btnHANGHOA_Click);
            // 
            // btnQLNCC
            // 
            this.btnQLNCC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.btnQLNCC.FlatAppearance.BorderSize = 0;
            this.btnQLNCC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnQLNCC.ForeColor = System.Drawing.Color.Black;
            this.btnQLNCC.Image = ((System.Drawing.Image)(resources.GetObject("btnQLNCC.Image")));
            this.btnQLNCC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQLNCC.Location = new System.Drawing.Point(0, 125);
            this.btnQLNCC.Name = "btnQLNCC";
            this.btnQLNCC.Size = new System.Drawing.Size(201, 50);
            this.btnQLNCC.TabIndex = 6;
            this.btnQLNCC.Text = "Nhà cung cấp";
            this.btnQLNCC.UseVisualStyleBackColor = false;
            this.btnQLNCC.Click += new System.EventHandler(this.btnQLNCC_Click);
            // 
            // btnQLCV
            // 
            this.btnQLCV.BackColor = System.Drawing.Color.Transparent;
            this.btnQLCV.FlatAppearance.BorderSize = 0;
            this.btnQLCV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLCV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnQLCV.ForeColor = System.Drawing.Color.Black;
            this.btnQLCV.Image = ((System.Drawing.Image)(resources.GetObject("btnQLCV.Image")));
            this.btnQLCV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQLCV.Location = new System.Drawing.Point(0, 67);
            this.btnQLCV.Name = "btnQLCV";
            this.btnQLCV.Size = new System.Drawing.Size(201, 50);
            this.btnQLCV.TabIndex = 4;
            this.btnQLCV.Text = "Chức vụ";
            this.btnQLCV.UseVisualStyleBackColor = false;
            this.btnQLCV.Click += new System.EventHandler(this.btnQLCV_Click);
            // 
            // btnHOADON
            // 
            this.btnHOADON.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.btnHOADON.FlatAppearance.BorderSize = 0;
            this.btnHOADON.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHOADON.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnHOADON.ForeColor = System.Drawing.Color.Black;
            this.btnHOADON.Image = ((System.Drawing.Image)(resources.GetObject("btnHOADON.Image")));
            this.btnHOADON.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHOADON.Location = new System.Drawing.Point(0, 239);
            this.btnHOADON.Name = "btnHOADON";
            this.btnHOADON.Size = new System.Drawing.Size(201, 50);
            this.btnHOADON.TabIndex = 3;
            this.btnHOADON.Text = "Hóa đơn";
            this.btnHOADON.UseVisualStyleBackColor = false;
            this.btnHOADON.Click += new System.EventHandler(this.btnHOADON_Click);
            // 
            // btnQLNV
            // 
            this.btnQLNV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.btnQLNV.FlatAppearance.BorderSize = 0;
            this.btnQLNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnQLNV.ForeColor = System.Drawing.Color.Black;
            this.btnQLNV.Image = ((System.Drawing.Image)(resources.GetObject("btnQLNV.Image")));
            this.btnQLNV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQLNV.Location = new System.Drawing.Point(0, 11);
            this.btnQLNV.Name = "btnQLNV";
            this.btnQLNV.Size = new System.Drawing.Size(201, 50);
            this.btnQLNV.TabIndex = 2;
            this.btnQLNV.Text = "Nhân viên";
            this.btnQLNV.UseVisualStyleBackColor = false;
            this.btnQLNV.Click += new System.EventHandler(this.button1_Click);
            this.btnQLNV.MouseHover += new System.EventHandler(this.btnQLNV_MouseHover);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(1018, 30);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 530);
            this.panel3.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(201, 550);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(817, 10);
            this.panel4.TabIndex = 3;
            // 
            // mainpanel
            // 
            this.mainpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainpanel.Location = new System.Drawing.Point(201, 30);
            this.mainpanel.Name = "mainpanel";
            this.mainpanel.Size = new System.Drawing.Size(817, 520);
            this.mainpanel.TabIndex = 4;
            this.mainpanel.Paint += new System.Windows.Forms.PaintEventHandler(this.mainpanel_Paint_1);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnClose);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(997, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(31, 30);
            this.panel5.TabIndex = 7;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.button2);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Location = new System.Drawing.Point(0, 477);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(201, 53);
            this.panel6.TabIndex = 18;
            // 
            // FrmHOME
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 560);
            this.Controls.Add(this.mainpanel);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmHOME";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmHOME";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmHOME_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picDOANHTHU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picINFO)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNHANVIEN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCHUCVU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNCC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHD)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnQLCV;
        private System.Windows.Forms.Button btnHOADON;
        private System.Windows.Forms.Button btnQLNV;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnQLNCC;
        private System.Windows.Forms.Button btnQLTK;
        private System.Windows.Forms.Button btnHANGHOA;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnINFO;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel mainpanel;
        private System.Windows.Forms.PictureBox picNHANVIEN;
        private System.Windows.Forms.PictureBox picCHUCVU;
        private System.Windows.Forms.PictureBox picTK;
        private System.Windows.Forms.PictureBox picHD;
        private System.Windows.Forms.PictureBox picHH;
        private System.Windows.Forms.PictureBox picNCC;
        private System.Windows.Forms.PictureBox picINFO;
        private System.Windows.Forms.PictureBox picDOANHTHU;
        private System.Windows.Forms.Button btnDOANHTHU;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
    }
}